// src/services/ShoppingFacade.js
//
// Facade Pattern — simplified interface over the complex subsystem.
//
// Chapter 12 mapping:
//   Facade     = ShoppingFacade (this class)
//   Subsystems = searchService, purchaseService, sessionStore, adapterFactory
//
// Why Facade here:
//   Without the Facade, the API routes must coordinate 4 subsystems:
//     1. adapterFactory → create adapter
//     2. searchService → execute search
//     3. sessionStore → store/consume adapter
//     4. purchaseService → execute purchase
//
//   The Facade hides this complexity behind two methods:
//     search(site, params)  → { products, sessionId }
//     purchase(params)      → { requestId }
//
//   The caller never knows about adapter lifecycle, session storage,
//   or the fire-and-forget background task. It just calls the Facade.
//
// Design:
//   - search() creates adapter → executes search → stores adapter in session → returns results
//   - purchase() consumes adapter from session → falls back to fresh adapter → fires background task
//   - Both methods handle the full coordination internally

const { executeSearch } = require('./searchService');
const { executePurchase } = require('./purchaseService');
const sessionStore = require('./sessionStore');
const { createAdapter } = require('../automation/adapters/adapterFactory');

class ShoppingFacade {
  /**
   * Search for products on a site.
   * Hides: adapter creation, search execution, session storage.
   *
   * @param {string} site — site identifier ('saucedemo', 'toolshop')
   * @param {{ query?: string, filters?: Object }} params
   * @returns {Promise<{ requestId, products, recommendedId, sessionId }>}
   */
  async search(site, { query, filters } = {}) {
    const adapter = createAdapter(site);
    const result = await executeSearch(adapter, { query, filters });
    const sessionId = sessionStore.store(adapter);

    return {
      requestId: result.requestId,
      products: result.products,
      recommendedId: result.recommendedId,
      sessionId,
    };
  }

  /**
   * Purchase a product.
   * Hides: session lookup, adapter fallback, fire-and-forget orchestration.
   *
   * @param {{ site: string, sessionId?: string, product: Object, shipping: Object }} params
   * @returns {Promise<{ requestId }>}
   */
  async purchase({ site, sessionId, product, shipping }) {
    // Try session continuity first, fall back to fresh adapter
    let adapter = sessionStore.consume(sessionId);

    if (!adapter || !adapter.isAlive || !adapter.isAlive()) {
      adapter = createAdapter(site);
    }

    return executePurchase(adapter, { product, shipping });
  }
}

module.exports = { ShoppingFacade };
